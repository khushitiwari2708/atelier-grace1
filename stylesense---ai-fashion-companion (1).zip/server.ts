import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("stylesense.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    name TEXT
  );

  CREATE TABLE IF NOT EXISTS wardrobe (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    item_name TEXT,
    category TEXT,
    color TEXT,
    last_worn DATE,
    image_url TEXT,
    usage_count INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS thrift_listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    item_name TEXT,
    price REAL,
    status TEXT DEFAULT 'available'
  );
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Wardrobe API
  app.get("/api/wardrobe", (req, res) => {
    const items = db.prepare("SELECT * FROM wardrobe").all();
    res.json(items);
  });

  app.post("/api/wardrobe", (req, res) => {
    const { item_name, category, color, image_url } = req.body;
    const info = db.prepare("INSERT INTO wardrobe (item_name, category, color, image_url) VALUES (?, ?, ?, ?)").run(item_name, category, color, image_url);
    res.json({ id: info.lastInsertRowid });
  });

  // Thrift API
  app.get("/api/thrift", (req, res) => {
    const listings = db.prepare("SELECT * FROM thrift_listings").all();
    res.json(listings);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
