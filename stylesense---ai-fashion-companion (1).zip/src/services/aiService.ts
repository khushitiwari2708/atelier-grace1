import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const orchestrator = {
  async routeRequest(request: { type: string; payload: any }) {
    switch (request.type) {
      case "CHECK_ON":
        return await this.checkOnBot(request.payload);
      case "FASHION_BOT":
        return await this.fashionBot(request.payload);
      case "THRIFT_BOT":
        return await this.thriftBot(request.payload);
      case "SEARCH_BOT":
        return await this.searchBot(request.payload);
      case "TIME_MACHINE":
        return await this.timeMachine(request.payload);
      default:
        throw new Error("Unknown agent type");
    }
  },

  async checkOnBot({ mood, occasion, weather, wardrobe }: any) {
    const prompt = `You are Check-On Bot, a friendly AI fashion stylist. 
    User Mood: ${mood}
    Occasion: ${occasion}
    Weather: ${weather}
    Wardrobe Items: ${JSON.stringify(wardrobe)}
    
    Suggest a comfortable and appropriate outfit from the wardrobe or general advice if wardrobe is empty. 
    Be supportive and stylish.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  },

  async fashionBot({ imageUrl, outfitType }: any) {
    const prompt = `Analyze this person's body shape and skin tone from the image and visualize them in a ${outfitType} style. 
    Provide a detailed description of how they would look in a 2D animation and a 3D avatar simulation.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        { text: prompt },
        { inlineData: { mimeType: "image/jpeg", data: imageUrl.split(",")[1] } }
      ],
    });

    return response.text;
  },

  async thriftBot({ wardrobe }: any) {
    const prompt = `Analyze this wardrobe usage data: ${JSON.stringify(wardrobe)}. 
    Identify items that haven't been worn lately and suggest whether the user should sell, donate, or exchange them. 
    Promote sustainable fashion.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  },

  async searchBot({ query, isImage }: any) {
    const prompt = isImage 
      ? "Identify this clothing item and find similar products on Myntra, Ajio, and Nykaa with estimated prices."
      : `Find "${query}" on Indian fashion platforms Myntra, Ajio, and Nykaa. Provide a price comparison table.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: isImage ? [{ text: prompt }, { inlineData: { mimeType: "image/jpeg", data: query.split(",")[1] } }] : prompt,
    });

    return response.text;
  },

  async timeMachine({ imageUrl, era }: any) {
    const prompt = `Transform this person's fashion style to the ${era} era. 
    Describe the outfit, hair, and accessories in detail as if they were in that time period.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        { text: prompt },
        { inlineData: { mimeType: "image/jpeg", data: imageUrl.split(",")[1] } }
      ],
    });

    return response.text;
  }
};
