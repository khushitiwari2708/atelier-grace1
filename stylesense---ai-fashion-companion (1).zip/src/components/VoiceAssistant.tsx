import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mic, MicOff, Volume2, VolumeX, Loader2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Types for Web Speech API
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: any) => void;
  onend: () => void;
}

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function VoiceAssistant() {
  const navigate = useNavigate();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showUI, setShowUI] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
        const current = event.results[0][0].transcript;
        setTranscript(current);
        if (event.results[0].isFinal) {
          handleCommand(current.toLowerCase());
        }
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, []);

  const speak = (text: string) => {
    if (!window.speechSynthesis) return;
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    // Get settings from localStorage if available
    const settings = JSON.parse(localStorage.getItem('voiceSettings') || '{}');
    const voices = window.speechSynthesis.getVoices();
    
    if (settings.voice) {
      const selectedVoice = voices.find(v => v.name.includes(settings.voice));
      if (selectedVoice) utterance.voice = selectedVoice;
    }
    
    utterance.rate = settings.speed || 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleCommand = (command: string) => {
    console.log('Processing command:', command);
    
    if (command.includes('go to') || command.includes('open') || command.includes('show')) {
      if (command.includes('home') || command.includes('dashboard')) {
        navigate('/');
        speak('Going to your dashboard.');
      } else if (command.includes('wardrobe') || command.includes('clothes') || command.includes('closet')) {
        navigate('/wardrobe');
        speak('Opening your wardrobe.');
      } else if (command.includes('chat') || command.includes('stylist') || command.includes('bot')) {
        navigate('/chat');
        speak('How can I help you style today?');
      } else if (command.includes('studio') || command.includes('visualize') || command.includes('avatar')) {
        navigate('/visualize');
        speak('Opening the visualization studio.');
      } else if (command.includes('search') || command.includes('find') || command.includes('shop')) {
        navigate('/search');
        speak('What are you looking for?');
      } else if (command.includes('thrift') || command.includes('market') || command.includes('sell')) {
        navigate('/thrift');
        speak('Opening the thrift marketplace.');
      } else if (command.includes('time machine') || command.includes('history')) {
        navigate('/timemachine');
        speak('Ready for a fashion time travel?');
      } else if (command.includes('culture') || command.includes('indian') || command.includes('learning')) {
        navigate('/cultural');
        speak('Exploring Indian cultural fashion.');
      } else if (command.includes('profile') || command.includes('settings')) {
        navigate('/profile');
        speak('Opening your profile settings.');
      }
    } else if (command.includes('hello') || command.includes('hi')) {
      speak('Hello! I am your Style Sense assistant. How can I help you today?');
    } else if (command.includes('weather')) {
      speak('It is currently 24 degrees and sunny. A perfect day for something light!');
    } else {
      speak("I heard you say " + command + ". I'm not sure how to help with that yet, but I can help you navigate the app.");
    }

    // Close UI after a delay
    setTimeout(() => {
      if (!isListening) setShowUI(false);
    }, 3000);
  };

  const toggleListening = () => {
    if (isListening) {
      recognition?.stop();
      setIsListening(false);
    } else {
      setTranscript('');
      setShowUI(true);
      recognition?.start();
      setIsListening(true);
    }
  };

  if (!recognition) return null;

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-24 right-6 md:bottom-8 md:right-8 z-[100]">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleListening}
          className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-colors ${
            isListening ? 'bg-rose-500 text-white animate-pulse' : 'bg-indigo-600 text-white'
          }`}
        >
          {isListening ? <Mic size={24} /> : <Mic size={24} />}
        </motion.button>
      </div>

      {/* Voice UI Overlay */}
      <AnimatePresence>
        {showUI && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-40 right-6 md:bottom-24 md:right-8 w-72 bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 z-[100] overflow-hidden"
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isListening ? 'bg-rose-500 animate-ping' : 'bg-stone-300'}`} />
                <span className="text-xs font-bold text-stone-400 uppercase tracking-widest">
                  {isListening ? 'Listening...' : 'Assistant'}
                </span>
              </div>
              <button onClick={() => setShowUI(false)} className="text-stone-400 hover:text-stone-600">
                <X size={16} />
              </button>
            </div>

            <div className="min-h-[60px] flex flex-col justify-center">
              {transcript ? (
                <p className="text-stone-800 font-medium leading-relaxed">"{transcript}"</p>
              ) : (
                <p className="text-stone-400 italic text-sm">Try saying "Go to Wardrobe" or "What's the weather?"</p>
              )}
            </div>

            {isSpeaking && (
              <div className="mt-4 flex items-center gap-2 text-indigo-600">
                <Volume2 size={16} className="animate-bounce" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Assistant is speaking</span>
              </div>
            )}

            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-indigo-50 rounded-full blur-3xl opacity-50 -z-10" />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
