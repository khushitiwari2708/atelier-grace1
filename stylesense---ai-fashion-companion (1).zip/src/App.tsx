/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  MessageSquare, 
  Shirt, 
  Sparkles, 
  Search, 
  Recycle, 
  History, 
  BookOpen, 
  Mic, 
  User,
  Menu,
  X,
  ChevronRight,
  TrendingUp,
  CloudSun
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Pages
import Dashboard from './pages/Dashboard';
import Chatbot from './pages/Chatbot';
import Wardrobe from './pages/Wardrobe';
import Visualization from './pages/Visualization';
import FashionSearch from './pages/FashionSearch';
import ThriftMarketplace from './pages/ThriftMarketplace';
import TimeMachine from './pages/TimeMachine';
import CulturalLearning from './pages/CulturalLearning';
import Profile from './pages/Profile';

// Components
import VoiceAssistant from './components/VoiceAssistant';

const navItems = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/chat', icon: MessageSquare, label: 'Stylist' },
  { path: '/wardrobe', icon: Shirt, label: 'Wardrobe' },
  { path: '/visualize', icon: Sparkles, label: 'Studio' },
  { path: '/search', icon: Search, label: 'Search' },
  { path: '/thrift', icon: Recycle, label: 'Thrift' },
  { path: '/timemachine', icon: History, label: 'Time Machine' },
  { path: '/cultural', icon: BookOpen, label: 'Culture' },
];

function Navigation() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Desktop Sidebar */}
      <nav className="hidden md:flex flex-col w-64 bg-white border-r border-stone-200 h-screen sticky top-0 p-6">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
            <Sparkles size={24} />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900">StyleSense</h1>
        </div>

        <div className="flex-1 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-indigo-50 text-indigo-600 font-medium' 
                    : 'text-stone-500 hover:bg-stone-50 hover:text-stone-900'
                }`}
              >
                <Icon size={20} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>

        <div className="pt-6 border-t border-stone-100">
          <Link to="/profile" className="flex items-center gap-3 px-4 py-3 rounded-xl text-stone-500 hover:bg-stone-50 hover:text-stone-900">
            <User size={20} />
            <span>Profile</span>
          </Link>
        </div>
      </nav>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-stone-200 px-4 py-2 flex justify-around items-center z-50">
        {navItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center gap-1 p-2 ${
                isActive ? 'text-indigo-600' : 'text-stone-400'
              }`}
            >
              <Icon size={20} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
        <button 
          onClick={() => setIsOpen(true)}
          className="flex flex-col items-center gap-1 p-2 text-stone-400"
        >
          <Menu size={20} />
          <span className="text-[10px] font-medium">More</span>
        </button>
      </nav>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] md:hidden"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed right-0 top-0 bottom-0 w-64 bg-white z-[70] p-6 shadow-2xl md:hidden"
            >
              <div className="flex justify-between items-center mb-8">
                <span className="font-bold text-lg">Menu</span>
                <button onClick={() => setIsOpen(false)}><X size={24} /></button>
              </div>
              <div className="space-y-4">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsOpen(false)}
                      className="flex items-center gap-3 text-stone-600 py-2"
                    >
                      <Icon size={20} />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
                <Link
                  to="/profile"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-3 text-stone-600 py-2 border-t border-stone-100 pt-4"
                >
                  <User size={20} />
                  <span>Profile</span>
                </Link>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

export default function App() {
  return (
    <Router>
      <div className="flex min-h-screen bg-stone-50 text-stone-900 font-sans">
        <Navigation />
        <main className="flex-1 p-4 md:p-8 pb-32 md:pb-8 max-w-6xl mx-auto w-full">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/chat" element={<Chatbot />} />
            <Route path="/wardrobe" element={<Wardrobe />} />
            <Route path="/visualize" element={<Visualization />} />
            <Route path="/search" element={<FashionSearch />} />
            <Route path="/thrift" element={<ThriftMarketplace />} />
            <Route path="/timemachine" element={<TimeMachine />} />
            <Route path="/cultural" element={<CulturalLearning />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </main>
        <VoiceAssistant />
      </div>
    </Router>
  );
}
