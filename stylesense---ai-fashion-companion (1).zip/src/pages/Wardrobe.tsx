import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Plus, Shirt, Trash2, Tag, Palette, Upload, Loader2 } from 'lucide-react';

interface WardrobeItem {
  id: number;
  item_name: string;
  category: string;
  color: string;
  image_url: string;
  usage_count: number;
}

export default function Wardrobe() {
  const [items, setItems] = useState<WardrobeItem[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [newItem, setNewItem] = useState({ item_name: '', category: 'Tops', color: '', image_url: '' });

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/wardrobe');
      const data = await res.json();
      setItems(data);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/wardrobe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newItem)
    });
    if (res.ok) {
      setNewItem({ item_name: '', category: 'Tops', color: '', image_url: '' });
      setIsAdding(false);
      fetchItems();
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-stone-900">My Wardrobe</h1>
          <p className="text-stone-500 mt-1">Manage your collection of {items.length} items.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-2xl font-medium hover:bg-indigo-700 transition-all active:scale-95 shadow-md shadow-indigo-200"
        >
          <Plus size={20} /> Add Item
        </button>
      </div>

      {isAdding && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm"
        >
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-400 uppercase tracking-wider">Item Name</label>
              <input 
                required
                type="text" 
                placeholder="e.g. Blue Denim Jacket"
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 outline-none focus:border-indigo-300"
                value={newItem.item_name}
                onChange={e => setNewItem({...newItem, item_name: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-400 uppercase tracking-wider">Category</label>
              <select 
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 outline-none focus:border-indigo-300"
                value={newItem.category}
                onChange={e => setNewItem({...newItem, category: e.target.value})}
              >
                <option>Tops</option>
                <option>Bottoms</option>
                <option>Outerwear</option>
                <option>Shoes</option>
                <option>Accessories</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-stone-400 uppercase tracking-wider">Color</label>
              <input 
                type="text" 
                placeholder="e.g. Navy Blue"
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 outline-none focus:border-indigo-300"
                value={newItem.color}
                onChange={e => setNewItem({...newItem, color: e.target.value})}
              />
            </div>
            <div className="flex items-end gap-2">
              <button type="submit" className="flex-1 bg-indigo-600 text-white py-2 rounded-xl font-medium">Save</button>
              <button type="button" onClick={() => setIsAdding(false)} className="px-4 py-2 text-stone-500 font-medium">Cancel</button>
            </div>
          </form>
        </motion.div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="animate-spin text-indigo-600" size={40} />
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-stone-300">
          <Shirt size={48} className="mx-auto text-stone-300 mb-4" />
          <h3 className="text-lg font-medium text-stone-900">Your wardrobe is empty</h3>
          <p className="text-stone-500 mt-1">Start by adding your favorite pieces!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {items.map((item) => (
            <motion.div 
              key={item.id}
              whileHover={{ y: -5 }}
              className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-sm group"
            >
              <div className="aspect-square bg-stone-100 relative overflow-hidden">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.item_name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-stone-300">
                    <Shirt size={48} />
                  </div>
                )}
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 bg-white/90 backdrop-blur-sm rounded-full text-rose-500 shadow-sm">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-stone-900 truncate">{item.item_name}</h3>
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-1 bg-stone-100 text-stone-500 rounded-md">
                    {item.category}
                  </span>
                  {item.color && (
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-1 bg-indigo-50 text-indigo-600 rounded-md">
                      {item.color}
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
