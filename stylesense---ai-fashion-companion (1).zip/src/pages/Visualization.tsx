import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Upload, Sparkles, Camera, Loader2, Info } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { orchestrator } from '../services/aiService';

export default function Visualization() {
  const [image, setImage] = useState<string | null>(null);
  const [outfitType, setOutfitType] = useState('Casual');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVisualize = async () => {
    if (!image) return;
    setIsLoading(true);
    try {
      const response = await orchestrator.routeRequest({
        type: 'FASHION_BOT',
        payload: { imageUrl: image, outfitType }
      });
      setResult(response);
    } catch (error) {
      setResult("Error generating visualization. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-stone-900">Visualization Studio</h1>
        <p className="text-stone-500 mt-1">See how different styles look on your body with AI avatars.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left: Input */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
            <h3 className="font-bold text-stone-900 flex items-center gap-2">
              <Camera size={20} className="text-indigo-600" /> Step 1: Upload your photo
            </h3>
            <div 
              onClick={() => document.getElementById('photo-upload')?.click()}
              className={`aspect-[3/4] rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all ${
                image ? 'border-indigo-300 bg-indigo-50/30' : 'border-stone-200 hover:border-indigo-300 hover:bg-stone-50'
              }`}
            >
              {image ? (
                <img src={image} alt="Upload" className="w-full h-full object-cover rounded-xl" />
              ) : (
                <>
                  <Upload size={40} className="text-stone-300 mb-4" />
                  <p className="text-stone-500 font-medium">Click to upload full-body photo</p>
                  <p className="text-stone-400 text-xs mt-1">Front-facing, clear lighting</p>
                </>
              )}
              <input 
                id="photo-upload" 
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleImageUpload}
              />
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-4">
            <h3 className="font-bold text-stone-900 flex items-center gap-2">
              <Sparkles size={20} className="text-indigo-600" /> Step 2: Choose Style
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {['Casual', 'Formal', 'Ethnic', 'Sporty', 'Streetwear', 'Party'].map((style) => (
                <button
                  key={style}
                  onClick={() => setOutfitType(style)}
                  className={`py-3 rounded-xl text-sm font-medium transition-all ${
                    outfitType === style 
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>
            <button
              disabled={!image || isLoading}
              onClick={handleVisualize}
              className="w-full bg-stone-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 transition-all active:scale-95 mt-4"
            >
              {isLoading ? <Loader2 className="animate-spin" /> : <Sparkles size={20} />}
              Generate AI Visualization
            </button>
          </div>
        </div>

        {/* Right: Output */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm h-full min-h-[400px] flex flex-col">
            <h3 className="font-bold text-stone-900 flex items-center gap-2 mb-6">
              <TrendingUp size={20} className="text-indigo-600" /> AI Output Preview
            </h3>
            
            {isLoading ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-10">
                <Loader2 size={48} className="text-indigo-600 animate-spin mb-4" />
                <h4 className="font-bold text-stone-900">Generating your avatar...</h4>
                <p className="text-stone-500 mt-2 text-sm">Our AI is analyzing your body shape, skin tone, and pose to create a perfect visualization.</p>
              </div>
            ) : result ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex-1 space-y-6"
              >
                <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100 flex gap-3">
                  <Info size={20} className="text-indigo-600 flex-shrink-0 mt-1" />
                  <p className="text-sm text-indigo-900 leading-relaxed">
                    The system has generated a 2D animated preview and a 3D avatar simulation based on your input.
                  </p>
                </div>
                <div className="prose prose-stone max-w-none">
                  <ReactMarkdown>{result}</ReactMarkdown>
                </div>
              </motion.div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-10 border-2 border-dashed border-stone-100 rounded-2xl">
                <Sparkles size={48} className="text-stone-200 mb-4" />
                <p className="text-stone-400 font-medium">Upload a photo and select a style to see the magic happen.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

import { TrendingUp } from 'lucide-react';
