import React, { useState } from 'react';
import { motion } from 'motion/react';
import { History, Camera, Sparkles, Loader2, Download, Share2 } from 'lucide-react';
import { orchestrator } from '../services/aiService';

export default function TimeMachine() {
  const [image, setImage] = useState<string | null>(null);
  const [era, setEra] = useState('1920s');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const eras = [
    { id: '1920s', name: '1920s Vintage', description: 'The era of flapper dresses and jazz.' },
    { id: '1950s', name: '1950s Retro', description: 'Rock and roll, poodle skirts, and classic suits.' },
    { id: '1980s', name: '1980s Bold', description: 'Neon colors, big hair, and power dressing.' },
    { id: 'futuristic', name: 'Futuristic', description: 'Sleek materials and avant-garde designs.' }
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleTravel = async () => {
    if (!image) return;
    setIsLoading(true);
    try {
      const response = await orchestrator.routeRequest({
        type: 'TIME_MACHINE',
        payload: { imageUrl: image, era }
      });
      setResult(response);
    } catch (error) {
      setResult("Error traveling through time. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-stone-900">Fashion Time Machine</h1>
        <p className="text-stone-500 mt-1">Upload a selfie and see yourself in iconic styles from different eras.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
            <h3 className="font-bold text-stone-900 mb-4 flex items-center gap-2">
              <Camera size={20} className="text-rose-500" /> Upload Selfie
            </h3>
            <div 
              onClick={() => document.getElementById('selfie-upload')?.click()}
              className={`aspect-square rounded-2xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all ${
                image ? 'border-rose-300 bg-rose-50/30' : 'border-stone-200 hover:border-rose-300 hover:bg-stone-50'
              }`}
            >
              {image ? (
                <img src={image} alt="Selfie" className="w-full h-full object-cover rounded-xl" />
              ) : (
                <>
                  <Camera size={40} className="text-stone-300 mb-4" />
                  <p className="text-stone-500 font-medium text-center px-4">Click to upload a clear selfie</p>
                </>
              )}
              <input id="selfie-upload" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
            <h3 className="font-bold text-stone-900 mb-4 flex items-center gap-2">
              <History size={20} className="text-rose-500" /> Select Era
            </h3>
            <div className="space-y-3">
              {eras.map((e) => (
                <button
                  key={e.id}
                  onClick={() => setEra(e.id)}
                  className={`w-full p-4 rounded-2xl text-left transition-all border ${
                    era === e.id 
                      ? 'bg-rose-50 border-rose-200 ring-2 ring-rose-100' 
                      : 'bg-stone-50 border-stone-100 hover:bg-stone-100'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className={`font-bold ${era === e.id ? 'text-rose-600' : 'text-stone-700'}`}>{e.name}</span>
                    {era === e.id && <Sparkles size={16} className="text-rose-500" />}
                  </div>
                  <p className="text-xs text-stone-500 mt-1">{e.description}</p>
                </button>
              ))}
            </div>
            <button
              disabled={!image || isLoading}
              onClick={handleTravel}
              className="w-full bg-rose-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 transition-all active:scale-95 mt-6 shadow-lg shadow-rose-100"
            >
              {isLoading ? <Loader2 className="animate-spin" /> : <History size={20} />}
              Travel to {era}
            </button>
          </div>
        </div>

        <div className="bg-stone-900 rounded-3xl p-8 text-white min-h-[500px] flex flex-col relative overflow-hidden">
          <div className="relative z-10 flex-1 flex flex-col">
            <h3 className="text-xl font-bold flex items-center gap-2 mb-8">
              <Sparkles className="text-rose-400" /> Transformation Result
            </h3>

            {isLoading ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                <div className="w-20 h-20 border-4 border-rose-500/30 border-t-rose-500 rounded-full animate-spin mb-6"></div>
                <h4 className="text-xl font-bold">Rerouting through time...</h4>
                <p className="text-stone-400 mt-2">Applying {era} fashion filters and AI reconstruction.</p>
              </div>
            ) : result ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex-1 flex flex-col"
              >
                <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/10 mb-6">
                  <p className="text-stone-300 leading-relaxed italic">"{result}"</p>
                </div>
                <div className="flex-1 rounded-2xl bg-stone-800 flex items-center justify-center border border-stone-700">
                  <p className="text-stone-500 text-sm">AI Visualization Preview</p>
                </div>
                <div className="mt-8 flex gap-4">
                  <button className="flex-1 bg-white text-stone-900 py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                    <Download size={18} /> Download
                  </button>
                  <button className="flex-1 bg-white/10 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                    <Share2 size={18} /> Share
                  </button>
                </div>
              </motion.div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center">
                <History size={64} className="text-stone-800 mb-6" />
                <p className="text-stone-500 max-w-xs">Your time-traveled fashion transformation will appear here.</p>
              </div>
            )}
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-rose-600/10 blur-[100px] rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/10 blur-[100px] rounded-full"></div>
        </div>
      </div>
    </div>
  );
}
