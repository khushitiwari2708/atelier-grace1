import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Recycle, ShoppingCart, Heart, Gift, Info, Loader2, TrendingUp } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { orchestrator } from '../services/aiService';

export default function ThriftMarketplace() {
  const [listings, setListings] = useState<any[]>([]);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchListings();
  }, []);

  const fetchListings = async () => {
    const res = await fetch('/api/thrift');
    const data = await res.json();
    setListings(data);
  };

  const analyzeWardrobe = async () => {
    setIsLoading(true);
    try {
      const wardrobeRes = await fetch('/api/wardrobe');
      const wardrobe = await wardrobeRes.json();
      const response = await orchestrator.routeRequest({
        type: 'THRIFT_BOT',
        payload: { wardrobe }
      });
      setAnalysis(response);
    } catch (error) {
      setAnalysis("Error analyzing wardrobe. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-stone-900">Thrift Bot & Marketplace</h1>
          <p className="text-stone-500 mt-1">Sustainable fashion: Sell, donate, or exchange your unused clothing.</p>
        </div>
        <button 
          onClick={analyzeWardrobe}
          className="bg-emerald-600 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all active:scale-95 shadow-lg shadow-emerald-100"
        >
          <TrendingUp size={20} /> Analyze My Closet
        </button>
      </header>

      {analysis && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-emerald-50 p-8 rounded-3xl border border-emerald-100 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm">
              <Recycle size={24} />
            </div>
            <div>
              <h3 className="font-bold text-emerald-900">Closet Sustainability Report</h3>
              <p className="text-sm text-emerald-700">AI-powered suggestions for your rarely worn items.</p>
            </div>
          </div>
          <div className="prose prose-emerald max-w-none">
            <ReactMarkdown>{analysis}</ReactMarkdown>
          </div>
          <div className="mt-8 flex gap-4">
            <button className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold">List Items for Sale</button>
            <button className="bg-white text-emerald-600 px-6 py-3 rounded-xl font-bold border border-emerald-200">Find Donation Centers</button>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Marketplace Feed */}
        <div className="md:col-span-2 space-y-6">
          <h2 className="text-xl font-bold text-stone-900 flex items-center gap-2">
            <ShoppingCart size={20} className="text-indigo-600" /> Community Exchange
          </h2>
          
          {listings.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-dashed border-stone-200 text-center">
              <Recycle size={48} className="mx-auto text-stone-200 mb-4" />
              <p className="text-stone-500">No active listings in your area yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {listings.map(item => (
                <div key={item.id} className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                  <div className="aspect-video bg-stone-100"></div>
                  <div className="p-6">
                    <div className="flex justify-between items-start">
                      <h3 className="font-bold text-stone-900">{item.item_name}</h3>
                      <span className="text-emerald-600 font-bold">₹{item.price}</span>
                    </div>
                    <p className="text-sm text-stone-500 mt-1">Excellent condition • Size M</p>
                    <div className="mt-6 flex gap-2">
                      <button className="flex-1 bg-indigo-600 text-white py-2 rounded-xl text-sm font-bold">Buy Now</button>
                      <button className="p-2 border border-stone-200 rounded-xl text-stone-400 hover:text-rose-500"><Heart size={20} /></button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
            <h3 className="font-bold text-stone-900 mb-4">Sustainability Stats</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-stone-500">Water Saved</span>
                <span className="font-bold text-indigo-600">2,400L</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-indigo-600 h-full w-[65%]"></div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-stone-500">CO2 Reduced</span>
                <span className="font-bold text-emerald-600">12.5kg</span>
              </div>
              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-600 h-full w-[40%]"></div>
              </div>
            </div>
          </div>

          <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
            <Gift className="text-indigo-600 mb-4" size={32} />
            <h3 className="font-bold text-indigo-900">Exchange Program</h3>
            <p className="text-sm text-indigo-700 mt-2 leading-relaxed">
              Swap items with other users for free! Join our community exchange program and refresh your wardrobe sustainably.
            </p>
            <button className="mt-4 w-full bg-indigo-600 text-white py-3 rounded-xl font-bold text-sm">Learn More</button>
          </div>
        </div>
      </div>
    </div>
  );
}
