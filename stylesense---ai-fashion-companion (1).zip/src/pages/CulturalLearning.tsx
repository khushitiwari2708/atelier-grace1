import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, MapPin, Info, ChevronRight, Sparkles, Heart } from 'lucide-react';

const culturalItems = [
  {
    id: 'saree',
    name: 'Saree Styles',
    region: 'Pan-India',
    description: 'The saree is one of the oldest forms of clothing in the world, with over 80 recorded ways to wear it.',
    styles: [
      { name: 'Kanjeevaram', origin: 'Tamil Nadu', detail: 'Rich silk sarees known for their wide contrast borders.' },
      { name: 'Banarasi', origin: 'Uttar Pradesh', detail: 'Fine silk sarees with intricate gold and silver brocade.' },
      { name: 'Paithani', origin: 'Maharashtra', detail: 'Hand-woven silk sarees with peacock motifs on the pallu.' }
    ]
  },
  {
    id: 'sherwani',
    name: 'Sherwani & Kurta',
    region: 'North India',
    description: 'Traditional long coat-like garment worn by men, often for weddings and formal ceremonies.',
    styles: [
      { name: 'Achkan', origin: 'Rajasthan', detail: 'A shorter, more fitted version of the sherwani.' },
      { name: 'Lucknowi Chikankari', origin: 'Uttar Pradesh', detail: 'Delicate and artful hand embroidery on fine fabrics.' }
    ]
  },
  {
    id: 'lehenga',
    name: 'Lehenga Choli',
    region: 'North & West India',
    description: 'A three-piece attire consisting of a long skirt, a fitted blouse, and a dupatta.',
    styles: [
      { name: 'Ghagra Choli', origin: 'Rajasthan/Gujarat', detail: 'Vibrant colors with mirror work and heavy embroidery.' },
      { name: 'Sharara', origin: 'Lucknow', detail: 'Flared pants that look like a skirt, paired with a short kurta.' }
    ]
  }
];

export default function CulturalLearning() {
  const [selected, setSelected] = useState(culturalItems[0]);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-stone-900">Indian Cultural Fashion</h1>
        <p className="text-stone-500 mt-1">Explore the rich heritage and diversity of Indian traditional attire.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar: Categories */}
        <div className="space-y-4">
          {culturalItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setSelected(item)}
              className={`w-full p-6 rounded-3xl text-left transition-all border ${
                selected.id === item.id 
                  ? 'bg-amber-50 border-amber-200 shadow-sm' 
                  : 'bg-white border-stone-100 hover:bg-stone-50'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className={`font-bold ${selected.id === item.id ? 'text-amber-900' : 'text-stone-900'}`}>{item.name}</h3>
                <ChevronRight size={18} className={selected.id === item.id ? 'text-amber-500' : 'text-stone-300'} />
              </div>
              <div className="flex items-center gap-1 text-xs text-amber-700 font-medium">
                <MapPin size={12} /> {item.region}
              </div>
            </button>
          ))}
          
          <div className="bg-stone-900 p-6 rounded-3xl text-white mt-8">
            <Sparkles className="text-amber-400 mb-4" size={24} />
            <h4 className="font-bold">Did you know?</h4>
            <p className="text-sm text-stone-400 mt-2 leading-relaxed">
              Cotton was first spun and woven in India over 5,000 years ago during the Indus Valley Civilization.
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <motion.div 
            key={selected.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm"
          >
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-bold text-stone-900">{selected.name}</h2>
                <p className="text-stone-500 mt-2 leading-relaxed">{selected.description}</p>
              </div>
              <button className="p-3 bg-stone-50 rounded-2xl text-stone-400 hover:text-rose-500 transition-colors">
                <Heart size={20} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
              <div className="aspect-[3/4] bg-stone-100 rounded-2xl overflow-hidden relative group">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                  <p className="text-white text-sm font-medium">Traditional Draping Style</p>
                </div>
                <div className="w-full h-full flex items-center justify-center text-stone-300">
                  <BookOpen size={48} />
                </div>
              </div>
              
              <div className="space-y-6">
                <h4 className="font-bold text-stone-900 flex items-center gap-2">
                  <Info size={18} className="text-amber-500" /> Regional Variations
                </h4>
                <div className="space-y-4">
                  {selected.styles.map((style, idx) => (
                    <div key={idx} className="p-4 bg-stone-50 rounded-2xl border border-stone-100">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold text-stone-900">{style.name}</span>
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-amber-100 text-amber-700 rounded-md">{style.origin}</span>
                      </div>
                      <p className="text-xs text-stone-500 leading-relaxed">{style.detail}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-10 pt-10 border-t border-stone-100">
              <h4 className="font-bold text-stone-900 mb-4">Occasions & Significance</h4>
              <div className="grid grid-cols-3 gap-4">
                {['Festivals', 'Weddings', 'Ceremonies'].map((occ) => (
                  <div key={occ} className="text-center p-4 rounded-2xl bg-amber-50/50 border border-amber-100">
                    <span className="text-xs font-bold text-amber-800">{occ}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
