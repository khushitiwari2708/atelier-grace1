import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Settings, Bell, Shield, CreditCard, Mic, LogOut, ChevronRight, Globe, Moon } from 'lucide-react';

export default function Profile() {
  const [user, setUser] = useState({
    name: 'Sriteja Erravalli',
    email: 'sritejayerravalli@gmail.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sriteja',
    stylePreference: 'Minimalist',
    language: 'English'
  });

  const [voiceSettings, setVoiceSettings] = useState(() => {
    const saved = localStorage.getItem('voiceSettings');
    return saved ? JSON.parse(saved) : {
      enabled: true,
      voice: 'Kore (Female)',
      speed: 1.0
    };
  });

  const updateVoiceSettings = (newSettings: any) => {
    const updated = { ...voiceSettings, ...newSettings };
    setVoiceSettings(updated);
    localStorage.setItem('voiceSettings', JSON.stringify(updated));
  };

  const menuItems = [
    { icon: Bell, label: 'Notifications', color: 'text-blue-500', bg: 'bg-blue-50' },
    { icon: Shield, label: 'Privacy & Security', color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { icon: CreditCard, label: 'Subscription', color: 'text-amber-500', bg: 'bg-amber-50' },
    { icon: Globe, label: 'Language', color: 'text-indigo-500', bg: 'bg-indigo-50', value: user.language },
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <header className="flex flex-col items-center text-center space-y-4">
        <div className="relative">
          <div className="w-24 h-24 rounded-full border-4 border-white shadow-xl overflow-hidden bg-stone-100">
            <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover" />
          </div>
          <button className="absolute bottom-0 right-0 p-2 bg-indigo-600 text-white rounded-full shadow-lg border-2 border-white">
            <Settings size={14} />
          </button>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-stone-900">{user.name}</h1>
          <p className="text-stone-500 text-sm">{user.email}</p>
        </div>
        <div className="flex gap-2">
          <span className="px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold uppercase tracking-wider border border-indigo-100">
            {user.stylePreference}
          </span>
          <span className="px-4 py-1.5 bg-stone-100 text-stone-600 rounded-full text-xs font-bold uppercase tracking-wider border border-stone-200">
            Premium Member
          </span>
        </div>
      </header>

      <div className="space-y-6">
        {/* Voice Assistant Settings */}
        <section className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-500">
                <Mic size={20} />
              </div>
              <div>
                <h3 className="font-bold text-stone-900">Voice Assistant</h3>
                <p className="text-xs text-stone-500">Multilingual voice interaction</p>
              </div>
            </div>
            <button 
              onClick={() => updateVoiceSettings({ enabled: !voiceSettings.enabled })}
              className={`w-12 h-6 rounded-full transition-colors relative ${voiceSettings.enabled ? 'bg-indigo-600' : 'bg-stone-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${voiceSettings.enabled ? 'left-7' : 'left-1'}`}></div>
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-stone-50 rounded-2xl border border-stone-100">
              <span className="text-sm font-medium text-stone-700">Voice Pack</span>
              <select 
                className="bg-transparent text-sm font-bold text-indigo-600 outline-none"
                value={voiceSettings.voice}
                onChange={e => updateVoiceSettings({ voice: e.target.value })}
              >
                <option>Kore (Female)</option>
                <option>Puck (Male)</option>
                <option>Zephyr (Female)</option>
                <option>Fenrir (Male)</option>
              </select>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-stone-400 uppercase">
                <span>Speech Speed</span>
                <span>{voiceSettings.speed}x</span>
              </div>
              <input 
                type="range" 
                min="0.5" 
                max="2.0" 
                step="0.1" 
                value={voiceSettings.speed}
                onChange={e => updateVoiceSettings({ speed: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-stone-100 rounded-full appearance-none accent-indigo-600"
              />
            </div>
          </div>
        </section>

        {/* General Settings */}
        <section className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
          {menuItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <button 
                key={item.label}
                className={`w-full flex items-center justify-between p-5 hover:bg-stone-50 transition-colors ${idx !== menuItems.length - 1 ? 'border-b border-stone-100' : ''}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 ${item.bg} ${item.color} rounded-xl flex items-center justify-center`}>
                    <Icon size={20} />
                  </div>
                  <span className="font-bold text-stone-700">{item.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  {item.value && <span className="text-sm text-stone-400">{item.value}</span>}
                  <ChevronRight size={18} className="text-stone-300" />
                </div>
              </button>
            );
          })}
        </section>

        <button className="w-full flex items-center justify-center gap-2 p-5 text-rose-500 font-bold hover:bg-rose-50 rounded-3xl transition-colors">
          <LogOut size={20} /> Sign Out
        </button>
      </div>
    </div>
  );
}
