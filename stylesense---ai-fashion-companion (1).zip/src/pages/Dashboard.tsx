import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles, TrendingUp, CloudSun, Shirt, Recycle, History } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const [weather, setWeather] = useState({ temp: 24, condition: 'Sunny' });
  const [stats, setStats] = useState({ wardrobeCount: 12, thriftListings: 3 });

  useEffect(() => {
    fetch('/api/wardrobe').then(res => res.json()).then(data => setStats(prev => ({ ...prev, wardrobeCount: data.length })));
  }, []);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-stone-900">Good morning, Fashionista!</h1>
        <p className="text-stone-500 mt-1">Your AI companion is ready to style you today.</p>
      </header>

      {/* Quick Stats & Weather */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex items-center justify-between"
        >
          <div>
            <p className="text-stone-500 text-sm font-medium">Today's Weather</p>
            <p className="text-2xl font-bold mt-1">{weather.temp}°C • {weather.condition}</p>
          </div>
          <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500">
            <CloudSun size={24} />
          </div>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex items-center justify-between"
        >
          <div>
            <p className="text-stone-500 text-sm font-medium">Wardrobe Items</p>
            <p className="text-2xl font-bold mt-1">{stats.wardrobeCount} Pieces</p>
          </div>
          <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-500">
            <Shirt size={24} />
          </div>
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm flex items-center justify-between"
        >
          <div>
            <p className="text-stone-500 text-sm font-medium">Thrift Activity</p>
            <p className="text-2xl font-bold mt-1">{stats.thriftListings} Active</p>
          </div>
          <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-500">
            <Recycle size={24} />
          </div>
        </motion.div>
      </div>

      {/* Main Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link to="/chat" className="group">
          <div className="bg-indigo-600 h-64 rounded-3xl p-8 text-white relative overflow-hidden transition-transform active:scale-95">
            <div className="relative z-10">
              <h2 className="text-2xl font-bold">Check-On Bot</h2>
              <p className="mt-2 text-indigo-100 max-w-xs">Get mood-based outfit suggestions and daily styling advice.</p>
              <div className="mt-6 inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full text-sm font-medium">
                Start Chatting <Sparkles size={16} />
              </div>
            </div>
            <MessageSquare className="absolute -bottom-10 -right-10 w-64 h-64 text-white/10 rotate-12" />
          </div>
        </Link>

        <Link to="/visualize" className="group">
          <div className="bg-stone-900 h-64 rounded-3xl p-8 text-white relative overflow-hidden transition-transform active:scale-95">
            <div className="relative z-10">
              <h2 className="text-2xl font-bold">Visualization Studio</h2>
              <p className="mt-2 text-stone-400 max-w-xs">See yourself in any outfit with our 2D & 3D AI avatars.</p>
              <div className="mt-6 inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full text-sm font-medium">
                Try On Outfits <TrendingUp size={16} />
              </div>
            </div>
            <Sparkles className="absolute -bottom-10 -right-10 w-64 h-64 text-white/5 -rotate-12" />
          </div>
        </Link>
      </div>

      {/* Secondary Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/timemachine" className="bg-rose-50 p-6 rounded-3xl border border-rose-100 group hover:bg-rose-100 transition-colors">
          <div className="w-12 h-12 bg-rose-500 rounded-2xl flex items-center justify-center text-white mb-4">
            <History size={24} />
          </div>
          <h3 className="font-bold text-rose-900">Fashion Time Machine</h3>
          <p className="text-sm text-rose-700 mt-1">Travel through eras of style.</p>
        </Link>

        <Link to="/thrift" className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 group hover:bg-emerald-100 transition-colors">
          <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-white mb-4">
            <Recycle size={24} />
          </div>
          <h3 className="font-bold text-emerald-900">Thrift Bot</h3>
          <p className="text-sm text-emerald-700 mt-1">Sustainable closet management.</p>
        </Link>

        <Link to="/cultural" className="bg-amber-50 p-6 rounded-3xl border border-amber-100 group hover:bg-amber-100 transition-colors">
          <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center text-white mb-4">
            <BookOpen size={24} />
          </div>
          <h3 className="font-bold text-amber-900">Cultural Learning</h3>
          <p className="text-sm text-amber-700 mt-1">Explore Indian heritage fashion.</p>
        </Link>
      </div>
    </div>
  );
}

import { MessageSquare, BookOpen } from 'lucide-react';
