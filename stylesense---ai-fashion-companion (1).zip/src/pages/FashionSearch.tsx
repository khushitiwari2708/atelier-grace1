import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Image as ImageIcon, ShoppingBag, ArrowRight, Loader2, DollarSign } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { orchestrator } from '../services/aiService';

export default function FashionSearch() {
  const [query, setQuery] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleSearch = async (isImgSearch = false) => {
    if (!query && !image) return;
    setIsLoading(true);
    try {
      const response = await orchestrator.routeRequest({
        type: 'SEARCH_BOT',
        payload: { query: isImgSearch ? image : query, isImage: isImgSearch }
      });
      setResult(response);
    } catch (error) {
      setResult("Error searching for products. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        handleSearch(true);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-stone-900">Fashion Search Bot</h1>
        <p className="text-stone-500 mt-1">Find any item across Myntra, Ajio, and Nykaa with real-time price comparison.</p>
      </header>

      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-4 rounded-3xl border border-stone-200 shadow-sm flex items-center gap-3 focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
          <Search className="text-stone-400 ml-2" size={24} />
          <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Search for 'Floral Summer Dress' or 'Blue Linen Shirt'..."
            className="flex-1 bg-transparent py-3 outline-none text-lg"
          />
          <button 
            onClick={() => document.getElementById('search-img')?.click()}
            className="p-3 text-stone-400 hover:text-indigo-600 transition-colors"
          >
            <ImageIcon size={24} />
          </button>
          <input id="search-img" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
          <button 
            onClick={() => handleSearch()}
            disabled={!query.trim() || isLoading}
            className="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'Search'}
          </button>
        </div>

        {isLoading ? (
          <div className="py-20 flex flex-col items-center justify-center text-center">
            <Loader2 size={48} className="text-indigo-600 animate-spin mb-4" />
            <h3 className="text-xl font-bold text-stone-900">Scanning platforms...</h3>
            <p className="text-stone-500 mt-2">We're checking Myntra, Ajio, and Nykaa for the best deals.</p>
          </div>
        ) : result ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm"
          >
            <div className="flex items-center gap-3 mb-6 pb-6 border-b border-stone-100">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600">
                <DollarSign size={24} />
              </div>
              <div>
                <h3 className="font-bold text-stone-900">Price Comparison Results</h3>
                <p className="text-sm text-stone-500">Found the best prices for your search.</p>
              </div>
            </div>
            <div className="prose prose-stone max-w-none">
              <ReactMarkdown>{result}</ReactMarkdown>
            </div>
            <div className="mt-8 flex gap-4">
              <button className="flex-1 bg-stone-100 text-stone-900 py-3 rounded-xl font-bold hover:bg-stone-200 transition-all">Save to Wishlist</button>
              <button className="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                Go to Store <ArrowRight size={18} />
              </button>
            </div>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-10">
            <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 text-center">
              <ShoppingBag className="mx-auto text-indigo-200 mb-4" size={32} />
              <h4 className="font-bold text-stone-900">Multi-Platform</h4>
              <p className="text-xs text-stone-500 mt-2">One search for all top Indian fashion stores.</p>
            </div>
            <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 text-center">
              <DollarSign className="mx-auto text-emerald-200 mb-4" size={32} />
              <h4 className="font-bold text-stone-900">Best Price</h4>
              <p className="text-xs text-stone-500 mt-2">Automatic comparison to save you money.</p>
            </div>
            <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 text-center">
              <ImageIcon className="mx-auto text-rose-200 mb-4" size={32} />
              <h4 className="font-bold text-stone-900">Visual Search</h4>
              <p className="text-xs text-stone-500 mt-2">Upload a photo to find matching outfits.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
