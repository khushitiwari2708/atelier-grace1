# StyleSense - AI Fashion Companion

StyleSense is a generative AI-driven intelligent fashion assistant designed to help users manage their wardrobe, receive personalized styling recommendations, visualize outfits using AI-generated avatars, and discover fashion products across multiple platforms.

## Features

- **Check-On Bot**: Conversational AI stylist for mood-based outfit suggestions.
- **Fashion Bot**: 2D/3D outfit visualization using AI avatars.
- **Thrift Bot**: Sustainable wardrobe management and marketplace.
- **Fashion Search Bot**: Smart shopping assistant with price comparison across Myntra, Ajio, and Nykaa.
- **Fashion Time Machine**: Visualize yourself in historical fashion styles.
- **Cultural Learning**: Explore Indian heritage fashion and traditional attire.
- **Voice Assistant**: Multilingual support for hands-free interaction.

## Tech Stack

- **Frontend**: React, Tailwind CSS, Lucide Icons, Motion.
- **Backend**: Express.js, SQLite (better-sqlite3).
- **AI**: Google Gemini API.
- **Build Tool**: Vite.

## Getting Started

### Prerequisites

- Node.js (v18+)
- Gemini API Key

### Installation

1. Clone the repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file based on `.env.example` and add your `GEMINI_API_KEY`.
4. Start the development server:
   ```bash
   npm run dev
   ```

### Deployment

The app is ready for deployment on Cloud Run or any Node.js hosting platform.

1. Build the frontend:
   ```bash
   npm run build
   ```
2. Start the production server:
   ```bash
   NODE_ENV=production node server.ts
   ```

## License

SPDX-License-Identifier: Apache-2.0
